const moodSelector = document.getElementById("mood");
const taskContainer = document.getElementById("taskContainer");
const taskList = document.getElementById("taskList");

const moodTasks = {
  happy: ["Start a creative project 🎨", "Call a friend 📞", "Plan a new goal 📅"],
  sad: ["Watch a feel-good movie 🎬", "Journal your feelings 📝", "Go for a walk 🚶‍♀️"],
  tired: ["Take a 15-min nap 😴", "Drink water 💧", "Do light stretching 🧘‍♂️"],
  stressed: ["Declutter a small space 🗂️", "Listen to calming music 🎧", "Take deep breaths 🌬️"],
  motivated: ["Finish an important task ✅", "Read a chapter 📚", "Create something new 🛠️"]
};

moodSelector.addEventListener("change", () => {
  const mood = moodSelector.value;
  taskList.innerHTML = "";
  if (mood && moodTasks[mood]) {
    moodTasks[mood].forEach(task => {
      const li = document.createElement("li");
      li.textContent = task;
      taskList.appendChild(li);
    });
    taskContainer.classList.remove("hidden");
  } else {
    taskContainer.classList.add("hidden");
  }
});

function solveDoubt() {
  const doubt = document.getElementById("doubt").value;
  const responseBox = document.getElementById("aiResponse");
  const responseText = document.getElementById("responseText");

  if (!doubt.trim()) return alert("Please enter your doubt!");

  responseText.textContent = `🤔 Analyzing your doubt: "${doubt}"... (Coming soon with ChatGPT API)`;
  responseBox.classList.remove("hidden");
}

function toggleDarkMode() {
  document.getElementById("mainBody").classList.toggle("dark");
}
