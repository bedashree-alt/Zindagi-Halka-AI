from flask import Flask, request, jsonify
import cv2
import pytesseract
from PIL import Image
import numpy as np
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/analyze-image', methods=['POST'])
def analyze_image():
    image_file = request.files['image']
    image = Image.open(image_file.stream).convert("RGB")
    np_image = np.array(image)

    text = pytesseract.image_to_string(np_image)

    boxes = pytesseract.image_to_boxes(image)
    for b in boxes.splitlines():
        b = b.split()
        if b[0].lower() == "x":
            x, y, w, h = map(int, b[1:5])
            cv2.rectangle(np_image, (x, image.height - y), (w, image.height - h), (255, 0, 0), 2)

    _, img_encoded = cv2.imencode('.png', np_image)
    return img_encoded.tobytes(), 200, {'Content-Type': 'image/png'}

if __name__ == '__main__':
    app.run(debug=True)
